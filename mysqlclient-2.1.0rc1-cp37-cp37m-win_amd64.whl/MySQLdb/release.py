
__author__ = "Inada Naoki <songofacandy@gmail.com>"
version_info = (2,1,0,'rc',1)
__version__ = "2.1.0rc1"
